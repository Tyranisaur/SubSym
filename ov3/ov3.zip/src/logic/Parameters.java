package logic;

public class Parameters {
	//6 + 5 + 3
	//30 + 15 
	public static int length = 45;
	public static double crossOverRate = .05;
	public static double mutationRate = 0.05;
	public static int adults = 800;
	public static double treshhold = - 0.25;
	public static int stepsPerGeneration = 60;
	public static boolean dynamicBoard = false;
	public static boolean newVisualizationScenario = true;
	public static int generationsPerRun = 100;
	public static int scanarios = 5;
	public static int millisPerVisualiztionStep = 1000;
	public static double tournamentPValue = 0.05;
	public static int tournamentSize = 80;

}
