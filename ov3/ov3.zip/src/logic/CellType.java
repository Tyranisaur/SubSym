package logic;

public enum CellType {
	FOOD, POISON, EMPTY, PLAYER;
}
