package logic;

public enum Impact {
	AVOIDBIG, AVOIDSMALL, CATCH, HIT, BIGPART, SMALLPART, VOID;
}
