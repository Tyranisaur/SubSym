package logic;

public enum GameType {
	STANDARD, PULL, NOWRAP;
}
