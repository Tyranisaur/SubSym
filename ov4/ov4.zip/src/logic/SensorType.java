package logic;

public enum SensorType {
	EMPTY, OBJECT, WALL;
}
