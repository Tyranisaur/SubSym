package logic;

public interface Coordinates {

	public int getX();
	public int getY();
}
