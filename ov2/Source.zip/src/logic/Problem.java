package logic;

public enum Problem {
	ONEMAX, LOLZ, LOCALSEQ, GLOBALSEQ;
}
