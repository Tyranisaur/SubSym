package logic;

public class Parameters {

	public static Problem problem;
	public static int birthRate;
	public static int adults;
	public static boolean adultsSurvive;
	public static int symbols;
	public static String oneMaxTarget;
	public static int lolzCap;
	public static int length;
	public static double crossOverRate;
	public static double mutationRate;
	public static int tournamentSize;
	public static double tournamentPValue;
	public static SelectionMode selectionMode;
}
