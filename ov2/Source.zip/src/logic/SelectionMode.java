package logic;

public enum SelectionMode {
	FITNESS, SIGMA, TOURNAMENT, UNIFORM;
}
